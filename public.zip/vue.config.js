// vue.config.js
module.exports = {
    publicPath: "",
    lintOnSave: false
}
