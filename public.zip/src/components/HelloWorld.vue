<template>
  <div class="main">
    <div class="link">
      <span class="net">{{netWork}}</span><span class="address">{{address}}</span>
    </div>
    <el-input v-model="name" placeholder="请输入合约合约名称（可选）" style="margin-bottom:15px;"></el-input>
    <el-input @blur="bornContranct" v-model="contractAddress" placeholder="请输入合约地址"></el-input>
    <el-input
      @blur="bornContranct"
      type="textarea"
      :rows="10"
      class="abi"
      placeholder="请输入ABI数组"
      v-model="abi">
    </el-input>
    <div style="margin:15px;">
      <el-button style="margin-right:15px;" :type="contractAddress==item.address ? 'primary' : 'default'" v-for="(item,index) in abiList" :key="index+'a'" @click="selectAbi(item)">{{item.name}}</el-button>
      <el-button type="primary" style="margin-right:15px;" @click="save()">保存</el-button>
      <el-button type="danger" style="margin-right:15px;" @click="del()">删除</el-button>
    </div>
    <div style="display:flex;align-items:center;justify-content: space-between;">
      <el-input style="margin-top:15px"  v-model="val" placeholder="数字(Number类型)"></el-input>
      <div style="width:20px;"></div>
      <el-input style="margin-top:15px"  v-model="decimals" placeholder="精度(Number类型)"></el-input>
    </div>
    <el-input style="margin-top:15px"  v-model="realVal" placeholder="处理精度后的数据"></el-input>
    <el-select class="select" @change="selectMethod" v-model="methodName" placeholder="请选择调用方法">
      <el-option
        v-for="(item,index) in methods"
        :key="index"
        :label="item.name"
        style="width:90%;box-sizing: border-box;"
        :value="item.name">
      </el-option>
    </el-select>
    <el-select  class="select" v-model="type" placeholder="请选择请求方式">
      <el-option
        v-for="(item,index) in types"
        :key="index"
        style="width:90%;box-sizing: border-box;"
        :label="item"
        :value="item">
      </el-option>
    </el-select>

    <el-input style="margin-top:15px" v-for="(item,index) in paramsInput" :key="index"  v-model="param[index]" :placeholder="item.name + '   ' + item.type"></el-input>
    
    
    <el-button  style="margin-top:15px" type="primary" @click="submit">提交</el-button>

    <div style="margin-top:15px" v-if="result">Result(查看控制台):{{result}}</div>
    <div style="margin-top:15px" v-if="result && result.transactionHash">
      transactionHash:{{result.transactionHash}}

      
    </div>
    <div style="margin-top:50px; display:flex;">
      <input type="text" v-model="hash" placeholder="查询交易">
      <el-button type="primary" style="margin-left:15px;" @click="getTransaction(hash)">查询</el-button>
    </div>
    <div style="margin-top:20px;">Transaction:{{transaction}}</div>
    <div style="margin-top:50px; display:flex;">
      <input type="text" v-model="msg" placeholder="签名消息">
      <el-button type="primary" style="margin-left:15px;" @click="getSign(msg)">签名</el-button>
    </div>
    <div style="margin-top:20px;">Sign:{{sign}}</div>
    
  </div>
</template>

<script>
import staking_abi from './abi.json'
export default {
    data(){
      return {
        abi:'',
        contractAddress:'',
        ContractObj:null,
        types:['send','call'],
        netWork:'',
        address:'',
        methodName:'',
        type:'',
        paramsInput:[],
        param:[],
        hash:'',
        curMethod:null,
        price:'',
        gas:'',
        result:null,
        decimals:18,
        val:'',
        transaction:null,
        msg:'',
        sign:'',
        name:'',
        abiList:[],
        curContract:''
      }
    },
    
    created(){
      this.web3Play.init().then(res=>{
         this.address = res[0]
         this.bornContranct()
         this.getWorkNet()
         this.changeHandle()
         this.getAbis()
      })
    },

    computed:{
      realVal(){
        if(!this.val){
          return ''
        }else{
          return this.longHandle(parseFloat(this.val),parseInt(this.decimals))
        }
      },
      methods(){
          let temp = []
          try{
            temp = JSON.parse(this.abi)
            
          }catch(err){
            temp = []
          }
          return temp.filter(item=>{
            return item.type == 'function'
          })
      }
    },
    methods:{
      del(){
        if(localStorage.getItem('abis')){
            let temp = JSON.parse(localStorage.getItem('abis'))
            temp = temp.filter(item=>{
              return item.address != this.contractAddress
            })
            localStorage.setItem('abis',JSON.stringify(temp))
          }
          this.getAbis()
      },
      save(){
          if(localStorage.getItem('abis')){
            let temp = JSON.parse(localStorage.getItem('abis'))
            temp.push({
              name:this.name,
              abi:this.abi,
              address:this.contractAddress
            })
            localStorage.setItem('abis',JSON.stringify(temp))
          }else{
            localStorage.setItem('abis',JSON.stringify([
              {
                name:this.name,
                abi:this.abi,
                address:this.contractAddress
              }
            ]))
          }
          this.getAbis()
      },
      selectAbi(obj){
        this.name = obj.name
        this.abi = obj.abi
        this.contractAddress = obj.address
        this.bornContranct()
      },
      getAbis(){
        if(localStorage.getItem('abis')){
            this.abiList = JSON.parse(localStorage.getItem('abis'))
        }
      },
      getSign(msg){
         window.web3.eth.personal.sign(msg,this.address, "").then(res=>{
           this.sign = res
         });
      },
      getTransaction(hash){
          window.web3.eth.getTransactionReceipt(hash).then(data=>{
              this.transaction = data
              console.log(this.transaction)
          });
      },
      getData(){
          return web3.eth.abi.encodeFunctionCall(this.curMethod, this.param)
      },
      submit(){
        this.param = this.param.map(item=>{
          return item.replace(/\s/g,'')
        })
        this.getPrice(()=>{
            this.$confirm(this.type == 'send' ? `Gas Price:${this.price}ETH 是否继续交易?` : '是否继续', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.swichParam()
            }).catch(() => {
                    
            });
        })
        // this.swichParam()
      },
      switchGas(fn){
        console.log(this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1]))
        switch(this.param.length){
          case 0:
            this.ContractObj.methods[this.curMethod.name]().estimateGas({from:this.address})
            .then((gasAmount)=>{
              this.gas = gasAmount
              console.log('gas:'+this.gas)
              fn()
            })
            .catch(function(error){
              console.log(error)
            });
          break;
          case 1:
            this.ContractObj.methods[this.curMethod.name](this.param[0]).estimateGas({from:this.address})
            .then((gasAmount)=>{
              this.gas = gasAmount
              console.log('gas:'+this.gas)
              fn()
            })
            .catch(function(error){
              console.log(error)
            });
          break;
          case 2:
            this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1]).estimateGas({from:this.address})
            .then((gasAmount)=>{
              this.gas = gasAmount
              console.log('gas:'+this.gas)
              fn()
            })
            .catch(function(error){
              console.log(error)
            });
          break;
        }
        
        
      },
      swichParam(fn = ()=>{}){
        switch(this.param.length){
          case 0:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name]().send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name]().call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          case 1:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name](this.param[0]).send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              }).catch(err=>{
                console.log(err)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name](this.param[0]).call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          case 2:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1]).send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1]).call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          case 3:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2]).send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2]).call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          case 4:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3]).send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3]).call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          case 5:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4]).send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4]).call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          case 6:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4],this.param[5]).send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4],this.param[5]).call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          case 7:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4],this.param[5],this.param[6]).send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4],this.param[5],this.param[6]).call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          case 8:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4],this.param[5],this.param[6],this.param[7]).send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4],this.param[5],this.param[6],this.param[7]).call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          case 9:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4],this.param[5],this.param[6],this.param[7],this.param[8]).send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4],this.param[5],this.param[6],this.param[7],this.param[8]).call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          case 10:
            if(this.type == 'send'){
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4],this.param[5],this.param[6],this.param[7],this.param[8],this.param[9]).send({
                from:this.address
              }).then(data=>{
                 this.result = data
                 console.log(data)
              })
            }else{
              this.ContractObj.methods[this.curMethod.name](this.param[0],this.param[1],this.param[2],this.param[3],this.param[4],this.param[5],this.param[6],this.param[7],this.param[8],this.param[9]).call().then(data=>{
                 this.result = data
                 console.log(data)
              })
            }
          break;
          
        }
      },
      selectMethod(n){
        
        let m = this.methods.find(item=>{
          return item.name == n
        })
        this.curMethod = m
        

        this.param = []
        if(m.stateMutability == 'view' || m.stateMutability == 'pure'){
          this.type = 'call'
        }else{
          this.type = 'send'
        }
        this.paramsInput = m.inputs ? m.inputs : []
        
      },
      watchHandle(){
        
      },
      changeHandle(){
         ethereum.on('accountsChanged', (data) => {
           window.defaultAccount = data[0]
           this.address = data[0].toLowerCase()
           this.getWorkNet()
         })
         ethereum.on('networkChanged', () => {
           this.getWorkNet()
         })
      },
      getWorkNet(){
        window.web3.eth.net.getId().then((ID)=>{
            switch(ID){
                case 1:
                    this.netWork = 'ETH'
                break;
                case 4:
                    this.netWork = 'Rinkeby'
                break;
                case 137:
                    this.netWork = 'Polygon'
                break;
                default:
                    this.netWork = '未知'
                break;
            }
        })
      },
      bornContranct(){
        if(this.abi && this.contractAddress){
          this.ContractObj = new window.web3.eth.Contract(JSON.parse(this.abi),this.contractAddress)
          console.log(this.ContractObj)
        }
      },
      getGas(fn){
        
        web3.eth.estimateGas({
            from:this.address,
            to: this.contractAddress,
            data: this.getData()
        }).then(gas=>{
          this.gas = gas
          
          fn()
        }).catch(err=>{
          alert(err)
        })
      },
      getPrice(fn=()=>{}){
        web3.eth.getGasPrice().then((price)=>{
          this.price = parseFloat(window.web3.utils.fromWei(price, 'ether'))
          console.log('price:'+price)
          this.getGas(fn)
        });
      }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.select{
  margin-top:15px;
  margin-right:15px;
}
.abi{
  margin-top:15px;
  
  
}
.link{
  height:40px;
  display: flex;
  align-items: center;
}
.net{
  margin-right:15px;
  font-size: 16px;
  font-weight: bold;
}
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
